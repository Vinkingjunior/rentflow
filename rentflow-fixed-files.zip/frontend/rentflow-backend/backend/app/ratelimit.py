import threading
import time
from collections import deque

from fastapi import HTTPException, Request, status


class RateLimiter:
    """In-memory sliding-window limiter, per process.
    With several workers/servers each keeps its own counts - use a shared store (e.g. Redis) then."""

    def __init__(self, max_calls: int, window_seconds: int):
        self.max_calls = max_calls
        self.window = window_seconds
        self._hits: dict[str, deque] = {}
        self._lock = threading.Lock()

    def hit(self, key: str) -> int:
        """Record a call. Returns 0 if allowed, otherwise the seconds to wait before retrying."""
        now = time.monotonic()
        with self._lock:
            if len(self._hits) > 10_000:  # drop idle keys so memory can't grow without bound
                for k in [k for k, q in self._hits.items() if not q or now - q[-1] > self.window]:
                    del self._hits[k]
            q = self._hits.setdefault(key, deque())
            while q and now - q[0] > self.window:
                q.popleft()
            if len(q) >= self.max_calls:
                return max(1, int(self.window - (now - q[0])) + 1)
            q.append(now)
            return 0


def client_ip(request: Request) -> str:
    # Behind a reverse proxy this is the proxy's address unless uvicorn is run with --proxy-headers
    return request.client.host if request.client else "unknown"


def rate_limit(limiter: RateLimiter):
    def dependency(request: Request) -> None:
        retry_after = limiter.hit(client_ip(request))
        if retry_after:
            raise HTTPException(
                status.HTTP_429_TOO_MANY_REQUESTS,
                "Too many attempts. Please try again later.",
                headers={"Retry-After": str(retry_after)},
            )
    return dependency
