from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models import User
from ..schemas import LoginResponse, MeOut
from ..ratelimit import RateLimiter, rate_limit
from ..security import DUMMY_PASSWORD_HASH, create_access_token, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])

login_limiter = RateLimiter(max_calls=10, window_seconds=60)  # per client IP


@router.post("/login", response_model=LoginResponse, dependencies=[Depends(rate_limit(login_limiter))])
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == form.username.strip().lower()))
    # Always run a bcrypt check (against a dummy hash if the email is unknown) to avoid a timing leak
    password_ok = verify_password(form.password, user.password_hash if user else DUMMY_PASSWORD_HASH)
    if user is None or not password_ok:
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Invalid email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return LoginResponse(
        access_token=create_access_token(user.id, user.role.value),
        role=user.role.value,
        tenant_id=user.tenant.id if user.tenant else None,
    )


@router.get("/me", response_model=MeOut)
def me(user: User = Depends(get_current_user)):
    return MeOut(
        id=user.id, email=user.email, role=user.role.value,
        tenant_id=user.tenant.id if user.tenant else None,
    )
